#!/bin/bash

PREFIX=`echo $(cd $HOME/../usr; pwd)`
exist=`which getconf`
if [ ! -n "$exist" ]; then
    apt install -y getconf
fi

if [ $(getconf LONG_BIT) -eq 32 ]; then
	echo "安装32bit版本"
    cp termux-tosee-api-armv7a $PREFIX/libexec/termux-tosee-api
else
	echo "安装64bit版本"
    cp termux-tosee-api-aarch64 $PREFIX/libexec/termux-tosee-api
fi

cp termux-tosee-callback $PREFIX/
echo "安装完成"
